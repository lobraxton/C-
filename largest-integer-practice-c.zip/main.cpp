/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std; 

int main()
{
   // initalize the array for 10 cells
    int userArr[10];
    
    // allows the user to enter the numbers into the array
    cout << "Enter 10 intergers: ";
    
    // stores the user input intergers in the array
    for (int i =0; i <10; i++){
        cin >> userArr[i];
    }
    
    //initalize largestInt to userArr[0] so the user can input positive and negative numbers.
    // after the user enters integers because if not, it will hold random memory value
    int largestInt = userArr[0]; 
    
    //searches the array for the largest interger
    for (int j = 1; j < 10; j++){
        if (userArr[j] > largestInt){
            largestInt = userArr[j];
        }
    }
    
    // displays the largest number entered
    cout << "The largest integer you entered it " << largestInt << endl;
    
    return 0;
}